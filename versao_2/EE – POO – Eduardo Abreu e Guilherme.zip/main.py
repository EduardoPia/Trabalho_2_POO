from bomberman import Bomberman

def main():
    jogo:Bomberman = Bomberman()
    jogo.executar()

if __name__ == "__main__":
    main()      